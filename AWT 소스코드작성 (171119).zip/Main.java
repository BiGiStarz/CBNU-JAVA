import java.awt.*;

class FrameTest extends Frame
{
	public FrameTest()
	{
		super("�� ��° �������Դϴ�.");
		setBounds(0,0,300,300);
		setVisible(true);
	}
}

class PanelTest extends Frame {
	public PanelTest(String str) {
		super(str);
		Panel panel1= new Panel();
		panel1.setBackground(Color.lightGray);
		add(panel1);
		setBounds(300,0,100,100);
		setSize(300, 300);
		setVisible(true);
	}
}

class ModelessDialog extends Frame {
	static final long serialVersionUID = 1;
	public ModelessDialog() {
		super("���̾�α� �׽�Ʈ");
		Dialog d = new Dialog(this, "������� ���̾�α�");
		d.setBounds(0,400,300,200);
		d.setVisible(true);
	}
}

class Button1 extends Frame {
	Button btn1, btn2, btn3;
	public Button1(String str) {
		super(str);
		Panel p = new Panel();
		btn1 = new Button("����");
		btn2 = new Button("����");
		btn3 = new Button("��");
		p.add(btn1); p.add(btn2); p.add(btn3);
		add(p);
		btn3.setEnabled(false);
		setBounds(600,0,600,0);
		setSize(200,200);
		setVisible(true);					
	}
}

class Checkbox1 extends Frame {
	public Checkbox1(String str) {
		super(str);
		Panel p = new Panel();
		Checkbox cbx1 = new Checkbox("�̴�", true);
		Checkbox cbx2 = new Checkbox("����");
		Checkbox cbx3 = new Checkbox("��");
		p.add(cbx1); p.add(cbx2); p.add(cbx3);
		
		CheckboxGroup group = new CheckboxGroup();
		Checkbox cbx4 = new Checkbox("�̴�", group, true);
		Checkbox cbx5 = new Checkbox("����", group, false);
		Checkbox cbx6 = new Checkbox("����", group, false);
		p.add(cbx4); p.add(cbx5); p.add(cbx6);
		
		add(p);
		setBounds(800,0,600,0);
		setSize(180, 300);
		setVisible(true);
	}
}

class ChoiceTest extends Frame {
	Choice ch;
	public ChoiceTest(String str) {
		super(str);
		ch = new Choice();
		ch.addItem("�̴�");
		ch.addItem("����");
		ch.addItem("��");
		add(ch);
		setBounds(0,300,600,0);
		setSize(300, 100);
		setVisible(true);
	}
}

class LabelTest extends Frame {
	Panel p; 
	Label label1, label2, label3;
	public LabelTest(String str) {
		super(str);
		p = new Panel();
		label1 = new Label("�̴�");
		label2 = new Label("����", Label.CENTER);
		label3 = new Label("��", Label.LEFT);
		label1.setBackground(Color.red);
		label2.setBackground(Color.blue);
		label3.setBackground(Color.green);
		p.add(label1); p.add(label2); p.add(label3);
		add(p);
		setBounds(300,300,600,0);
		setSize(300, 300);
		setVisible(true);
	}
}

class MenuTest1 extends Frame 
{
	public MenuTest1(String str) 
	{
		super(str);
		MenuBar mb = new MenuBar();
		Menu file = new Menu("����");
		MenuItem file_new = new MenuItem("���� �����");
		MenuItem file_open = new MenuItem("����");
		MenuItem file_save = new MenuItem("�ٸ� �̸����� ����");
		MenuItem file_newname = new MenuItem("����");

		file.add(file_new); 
		file.add(file_open);
		file.add(file_save);
		file.add(file_newname);
    
		Menu edit = new Menu("����");
		MenuItem edit_undo = new MenuItem("�������"); 
		MenuItem edit_cut = new MenuItem("�߶󳻱�");
		MenuItem edit_copy = new MenuItem("����");
		MenuItem edit_paste = new MenuItem("�ٿ��ֱ�");
		edit.add(edit_undo);
		edit.add(edit_cut);
		edit.add(edit_copy);
		edit.add(edit_paste);

		Menu view = new Menu("����");
		CheckboxMenuItem view_status = new CheckboxMenuItem("����ǥ����");
		view.add(view_status);
		
		Menu help = new Menu("����");
		MenuItem help_viewHelp = new MenuItem("���� ����");
		MenuItem help_about = new MenuItem("����");
		help.add(help_viewHelp);
		help.add(help_about);
		
		mb.add(file);
		mb.add(edit);
		mb.add(view);
		mb.add(help);
		
		setMenuBar(mb);
		setBounds(600,200,0,0);
		setSize(200,200);
		setVisible(true);
	}
}

class FlowLayoutTest extends Frame {
	FlowLayout f = new FlowLayout();
	Button btn[] = new Button[10];
	public FlowLayoutTest(String str) {
		super(str);
		setLayout(f);
		for(int i = 0; i < 10; i++) {
			btn[i] = new Button((i+1) + "�� ��ư");
			add(btn[i]);
		}
		setBounds(800, 300, 180, 200);
		setVisible(true);
	}
}

class BorderLayoutTest1 extends Frame 
{
	public BorderLayoutTest1(String str) 
	{
		super(str);
		setLayout(new BorderLayout());
		add("North", new Button("����"));
		add("West", new Button("����"));
		add("East", new Button("����"));
		add("Center", new Button("�߾�"));
		add("South", new Button("����"));

		setBounds(600,400,200,200);
		setVisible(true);
	}
}

public class Main {
	public static void main(String args[])
	{
		FrameTest Obj = new FrameTest();
		new PanelTest("�г� �׽�Ʈ");
		new ModelessDialog();
		new Button1("��ư �����");
		new Checkbox1("üũ�ڽ�");
		new ChoiceTest("�޺��ڽ�");
		new LabelTest("���̺�");
		new MenuTest1("�޴� �׽�Ʈ 1");
		new FlowLayoutTest("FlowLayout �׽�Ʈ");
		new BorderLayoutTest1("BorderLayout ����");
	}
}


