
public class DoWhileTest {
	public static void main(String[] args)
	{
		int a = 0;
		do
		{
			a++;
			System.out.println("a=" + a);
		}
		while (a < 10);
	}
}
