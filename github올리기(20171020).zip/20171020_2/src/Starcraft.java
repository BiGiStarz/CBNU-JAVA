abstract class Starcraft {
	abstract void attack();
}
